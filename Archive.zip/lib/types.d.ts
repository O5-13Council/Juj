declare module '@dynamic-pkg/bare-client';
declare module '@dynamic-pkg/acorn';
declare module '@dynamic-pkg/astring';
declare module '@dynamic-pkg/cookie';
declare module '@dynamic-pkg/mime';
declare module '@dynamic-pkg/base64';
declare module '@dynamic-pkg/mutation';