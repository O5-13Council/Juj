export default [
    {
        name: 'get',
        function: 'self',
    },
    {
        name: 'func',
        function: 'self',
    },
    {
        name: 'location',
        function: 'self',
    },
    {
        name: 'mutation',
        function: 'self',
    },
    {
        name: 'dom',
        function: 'self',
    },
    {
        name: 'write',
        function: 'self',
    },
    {
        name: 'message',
        function: 'self',
    },
    {
        name: 'reflect',
        function: 'self',
    },
    {
        name: 'window',
        function: 'self',
    },
    {
        name: 'eval',
        function: 'self',
    },
    {
        name: 'attr',
        function: 'self',
    },
    {
        name: 'policy',
        function: 'self',
    },
    {
        name: 'worker',
        function: 'self',
    },
    {
        name: 'history',
        function: 'self',
    },
    {
        name: 'ws',
        function: 'self',
    },
    {
        name: 'cookie',
        function: 'self',
    },
    {
        name: 'fetch',
        function: 'self',
    },
    {
        name: 'niche',
        function: 'self',
    },
    {
        name: 'storage',
        function: 'self',
    },
    {
        name: 'style',
        function: 'self',
    },
    {
        name: 'rtc',
        function: 'self',
    },
    {
        name: 'blob',
        function: 'self',
    },
    {
        name: 'navigator',
        function: 'self',
    }
] as Array<{name: string, function: string}>;